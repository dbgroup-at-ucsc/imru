package exp.test0.imruTest.dynamicTree;

import java.io.Serializable;

public class LockRequest extends SwapCommand {
    boolean isParentNode;
    int newTargetPartition;

    @Override
    public String toString() {
        return (isParentNode ? "" : "*")+"Lock swapTo="+newTargetPartition;
    }
}