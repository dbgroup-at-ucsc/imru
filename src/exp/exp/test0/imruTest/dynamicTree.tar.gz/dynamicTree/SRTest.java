/*
 * Copyright 2009-2010 by The Regents of the University of California
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * you may obtain a copy of the License from
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package exp.test0.imruTest.dynamicTree;

import java.io.IOException;
import java.util.EnumSet;

import edu.uci.ics.hyracks.api.client.HyracksConnection;
import edu.uci.ics.hyracks.api.client.IHyracksClientConnection;
import edu.uci.ics.hyracks.api.constraints.PartitionConstraintHelper;
import edu.uci.ics.hyracks.api.job.JobFlag;
import edu.uci.ics.hyracks.api.job.JobId;
import edu.uci.ics.hyracks.api.job.JobSpecification;
import edu.uci.ics.hyracks.control.cc.ClusterControllerService;
import edu.uci.ics.hyracks.control.common.controllers.CCConfig;
import edu.uci.ics.hyracks.control.common.controllers.NCConfig;
import edu.uci.ics.hyracks.control.nc.NodeControllerService;
import edu.uci.ics.hyracks.imru.dataflow.SpreadConnectorDescriptor;
import edu.uci.ics.hyracks.imru.example.utils.Client;
import edu.uci.ics.hyracks.imru.util.Rt;

public class SRTest {
    static int[] getAggregationTree(int nodeCount) {
        int[] targets = new int[nodeCount];
        targets[0] = -1; //root node;
        for (int i = 1; i < targets.length; i++) {
            targets[i] = (i - 1) / 2;
            //            Rt.p(i + "\t" + targets[i]);
        }
        return targets;
    }

    public static JobSpecification createJob(String[] mapOperatorLocations)
            throws InterruptedException, IOException {
        int[] targets = getAggregationTree(mapOperatorLocations.length);

        JobSpecification job = new JobSpecification();
        SendOD send = new SendOD(job, targets);
        RecvOD recv = new RecvOD(job, targets);
        job.connect(new SpreadConnectorDescriptor(job, null, null), send, 0,
                recv, 0);
        PartitionConstraintHelper.addAbsoluteLocationConstraint(job, send,
                mapOperatorLocations);
        PartitionConstraintHelper.addAbsoluteLocationConstraint(job, recv,
                mapOperatorLocations);
        job.addRoot(recv);
        return job;
    }

    public static void main(String[] args) throws Exception {
        Rt.showTime = false;
        //        SendOperator.fixedTree=true;

        //start cluster controller
        CCConfig ccConfig = new CCConfig();
        ccConfig.clientNetIpAddress = "127.0.0.1";
        ccConfig.clusterNetIpAddress = "127.0.0.1";
        ccConfig.clusterNetPort = 1099;
        ccConfig.clientNetPort = 3099;
        ccConfig.defaultMaxJobAttempts = 0;
        ccConfig.jobHistorySize = 10;
        ccConfig.appCCMainClass = "edu.uci.ics.hyracks.imru.runtime.bootstrap.IMRUCCBootstrapImpl";

        //start node controller
        ClusterControllerService cc = new ClusterControllerService(ccConfig);
        cc.start();

        String[] nodes = new String[5];
        for (int i = 0; i < nodes.length; i++) {
            NCConfig config = new NCConfig();
            config.ccHost = "127.0.0.1";
            config.ccPort = 1099;
            config.clusterNetIPAddress = "127.0.0.1";
            config.dataIPAddress = "127.0.0.1";
            config.datasetIPAddress = "127.0.0.1";
            config.appNCMainClass = "edu.uci.ics.hyracks.imru.runtime.bootstrap.IMRUNCBootstrapImpl";
            nodes[i] = config.nodeId = "NC" + i;
            NodeControllerService nc = new NodeControllerService(config);
            nc.start();
        }

        Client.disableLogging();

        //connect to hyracks
        IHyracksClientConnection hcc = new HyracksConnection("localhost", 3099);

        //update application
        hcc.deployBinary(null);

        try {

            JobSpecification job = createJob(nodes);

            JobId jobId = hcc.startJob(job, EnumSet.noneOf(JobFlag.class));
            hcc.waitForCompletion(jobId);

        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            Thread.sleep(1000);
            System.exit(0);
        }
    }
}