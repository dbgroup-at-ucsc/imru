package exp.test0.imruTest.dynamicTree;

public class ReleaseLock extends SwapCommand {
    @Override
    public String toString() {
        return "Release";
    }
}