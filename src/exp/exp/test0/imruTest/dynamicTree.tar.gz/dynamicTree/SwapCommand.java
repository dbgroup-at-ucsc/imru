package exp.test0.imruTest.dynamicTree;

import java.io.Serializable;

public class SwapCommand implements Serializable {
}
